#!/bin/bash

set -e
./docker-compose.sh up -d

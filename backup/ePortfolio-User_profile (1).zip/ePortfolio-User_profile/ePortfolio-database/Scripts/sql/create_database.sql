CREATE DATABASE eportfolio_db;

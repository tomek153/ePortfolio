DROP ROLE eportfolio_user;

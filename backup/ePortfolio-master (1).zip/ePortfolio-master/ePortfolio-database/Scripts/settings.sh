#!/bin/bash

# Docker image for EP components.
export postgres_image="postgres:latest"
